@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "JP=Sega Ages 2500 Series Vol. 17 - Phantasy Star Generation-2 (Japan).bin"
set "ENGX=PhantasyStarG2_T-Eng_v400.xdelta"
set "ENG=PSGEN2-ENGv400.bin"
set "PATCH=PSG2_DE_20261027_232210.xdelta"
set "OUT=PSG2_DE_20261027_232210.bin"
set "SHA=0038bd9f5275050ebf385d85ae2ac8ec08b31db7"

if not exist "%ENG%" (
  if exist "%JP%" if exist "%ENGX%" (
    echo Schritt 1: englische Basis v4.00 wird erzeugt ...
    xdelta3.exe -d -s "%JP%" "%ENGX%" "%ENG%"
    if errorlevel 1 (echo FEHLER bei Schritt 1 & pause & exit /b 1)
  )
)
if not exist "%ENG%" (
  echo.
  echo FEHLT: %ENG%
  echo Lege entweder %ENG% hierher
  echo oder die japanische Original-BIN und %ENGX% ^(siehe LIESMICH.txt^).
  pause & exit /b 1
)
echo Schritt 2: deutscher Patch wird angewendet ... ^(dauert ca. 1 Minute^)
xdelta3.exe -d -f -s "%ENG%" "%PATCH%" "%OUT%"
if errorlevel 1 (echo FEHLER bei Schritt 2. Stimmt die Basis-Datei? Siehe LIESMICH.txt. & pause & exit /b 1)

echo Pruefsumme wird berechnet ...
set "H="
for /f "skip=1 tokens=* delims=" %%A in ('certutil -hashfile "%OUT%" SHA1') do if not defined H set "H=%%A"
set "H=%H: =%"
if /i "%H%"=="%SHA%" (echo Pruefsumme OK.) else (echo ACHTUNG: Pruefsumme stimmt nicht! Bitte Marcel melden. & echo Erwartet: %SHA% & echo Erhalten: %H%)
echo.
echo Fertig: %OUT%
echo In PCSX2 die Datei PSG2_DE_20261027_232210.cue starten ^(oder die .bin^).
pause
